# O'zbek klaviatura (yangi alifbo)

## APK yig'ish
**Android Studio:** papkani oching -> Build > Build APK(s). Natija: app/build/outputs/apk/debug/app-debug.apk
**GitHub:** loyihani repoga yuklang -> Actions > Build APK > artifact'dan yuklab oling.

## Telefonda yoqish
Ilovani oching -> "Klaviaturani yoqish" -> "O'zbek klaviatura"ni yoqing -> "Klaviaturani tanlash".
