package uz.alifbo.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 18f
            text = "Yangi o'zbek alifbosi klaviaturasi\n\n" +
                "Harflar: Ç ç, Ğ ğ, Ö ö, Ş ş va tutuq belgisi (ʼ).\n\n" +
                "1) Klaviaturani yoqing\n2) Klaviaturani tanlang"
        })
        root.addView(Button(this).apply {
            text = "1) Klaviaturani yoqish"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2) Klaviaturani tanlash"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(EditText(this).apply { hint = "Shu yerda sinab ko'ring" })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
