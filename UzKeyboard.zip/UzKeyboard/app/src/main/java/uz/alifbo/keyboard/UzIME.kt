package uz.alifbo.keyboard

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * Yangi o'zbek lotin alifbosi (28 harf + tutuq belgisi) klaviaturasi.
 * Yangi harflar: Ç ç, Ğ ğ, Ö ö, Ş ş. Tutuq belgisi: ʼ (U+02BC).
 */
class UzIME : InputMethodService() {

    private enum class Shift { OFF, ONCE, CAPS }

    private var shift = Shift.ONCE
    private var symbols = false
    private var lastShiftTap = 0L
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private val letters = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l", "ö"),
        listOf("⇧", "z", "x", "v", "b", "n", "m", "ğ", "⌫"),
        listOf("?123", "ç", "ş", "ʼ", " ", ".", ",", "⏎")
    )
    private val syms = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("-", "/", ":", ";", "(", ")", "%", "&", "@", "\""),
        listOf("#", "$", "+", "=", "*", "!", "?", "'", "⌫"),
        listOf("ABC", "ʼ", "_", "<", " ", ">", ".", "⏎")
    )

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#ECEFF1"))
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        if (shift != Shift.CAPS) shift = if (shouldAutoCap()) Shift.ONCE else Shift.OFF
        if (::root.isInitialized) render()
    }

    private fun shouldAutoCap(): Boolean {
        val before = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: return true
        val t = before.trimEnd(' ')
        return before.isEmpty() || t.isEmpty() || (before.endsWith(" ") && t.last() in ".!?") || before.endsWith("\n")
    }

    private fun render() {
        root.removeAllViews()
        val layout = if (symbols) syms else letters
        for (row in layout) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(0, dp(3), 0, dp(3)) }
            }
            for (k in row) r.addView(makeKey(k))
            root.addView(r)
        }
    }

    private fun label(k: String): String = when {
        symbols || k.length != 1 || !k[0].isLetter() -> when (k) {
            " " -> "Oʻzbekcha"
            "⇧" -> if (shift == Shift.CAPS) "⇪" else "⇧"
            else -> k
        }
        shift == Shift.OFF -> k
        else -> k.uppercase(Locale.ROOT)
    }

    private fun makeKey(k: String): View {
        val special = k in setOf("⇧", "⌫", "?123", "ABC", "⏎")
        val weight = when (k) { " " -> 4f; "⇧", "⌫" -> 1.4f; "?123", "ABC", "⏎" -> 1.5f; else -> 1f }
        val tv = TextView(this).apply {
            text = label(k)
            gravity = Gravity.CENTER
            textSize = if (k == " ") 13f else 20f
            typeface = Typeface.DEFAULT
            setTextColor(Color.parseColor("#212121"))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor(if (special) "#CFD8DC" else "#FFFFFF"))
            }
            layoutParams = LinearLayout.LayoutParams(0, -1, weight).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onKey(k)
                    if (k == "⌫") scheduleRepeat()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacksAndMessages(null)
                }
            }
            true
        }
        return tv
    }

    private fun scheduleRepeat() {
        handler.postDelayed(object : Runnable {
            override fun run() { deleteBack(); handler.postDelayed(this, 50) }
        }, 400)
    }

    private fun deleteBack() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun onKey(k: String) {
        val ic = currentInputConnection ?: return
        when (k) {
            "⌫" -> deleteBack()
            "⇧" -> {
                val now = System.currentTimeMillis()
                shift = when {
                    shift == Shift.CAPS -> Shift.OFF
                    now - lastShiftTap < 350 -> Shift.CAPS
                    shift == Shift.ONCE -> Shift.OFF
                    else -> Shift.ONCE
                }
                lastShiftTap = now
                render()
            }
            "?123" -> { symbols = true; render() }
            "ABC" -> { symbols = false; render() }
            "⏎" -> {
                val info = currentInputEditorInfo
                val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noEnter = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.performEditorAction(action)
                else ic.commitText("\n", 1)
            }
            else -> {
                val isLetter = k.length == 1 && k[0].isLetter() && !symbols
                val out = if (isLetter && shift != Shift.OFF) k.uppercase(Locale.ROOT) else k
                ic.commitText(out, 1)
                if (isLetter && shift == Shift.ONCE) { shift = Shift.OFF; render() }
                else if (k == "." || k == "!" || k == "?") {
                    if (shift == Shift.OFF) { shift = Shift.ONCE; render() }
                }
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
